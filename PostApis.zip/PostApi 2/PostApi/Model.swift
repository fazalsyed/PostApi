//
//  Model.swift
//  PostApi
//
//  Created by syed fazal abbas on 25/05/23.
//

import Foundation

struct userData : Codable{
    let address : addressData?
    let id : Int
    let email : String
    let username : String
    let password : String
    let name : nameData?
    let phone : String
    let __v : Int
}
struct nameData : Codable{
    let firstname : String
    let lastname : String
}
struct addressData : Codable{
    let geolocation : geolocationData?
    let city : String
    let street : String
    let number : Int
    let zipcode : String
}
struct geolocationData : Codable{
    let lat : String
    let long : String
}
